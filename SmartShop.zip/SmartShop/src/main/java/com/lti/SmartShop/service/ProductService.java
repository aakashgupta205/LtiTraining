package com.lti.SmartShop.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.SmartShop.dao.ProductRepository;
import com.lti.SmartShop.model.Products;

@Service
public class ProductService {
	
	
	@Autowired
	ProductRepository repository;
	
	
	public Products addProduct(Products product) {
		return repository.save(product);	
	}
	
	public List<Products> getAllProducts(){
		return repository.findAll();
	}
	
	public Products updateProduct(Products product,Long id) throws com.lti.SmartShop.exception.ResourceNotFoundException {
		Products p1 = repository.findById(id).orElseThrow(() -> new com.lti.SmartShop.exception.ResourceNotFoundException("product id  not found "+ id));
		p1.setCategory(product.getCategory());
		p1.setName(product.getName());
		p1.setQuantity(product.getQuantity());
		p1.setUnitPrice(product.getUnitPrice());
		p1.setRating(product.getRating());
		p1.setTotalPrice(product.getTotalPrice());
		repository.save(p1);
		return p1;
	}
	
	public String updateTotalPrice() {
	List<Products> productList = repository.findAll();
	

	for(Products p: productList) {
		p.setTotalPrice(p.getQuantity()*p.getUnitPrice());
		repository.save(p);
	}
		return "total price updated";
	}
	
	public Products searchByName(String name) {
		return repository.searchbyName(name);
	}
	
	/*
	 * public List<Products> searchByCategory(String name) { List<Products>
	 * productListByCategory=null; List<Products> productsList =
	 * repository.findAll(); List<Products> filteredBYCategory =
	 * productsList.stream().filter(product->product.getCategory().equalsIgnoreCase(
	 * name)).collect(Collectors.toList()); for(Products p : filteredBYCategory) {
	 * productListByCategory.add(p); } return productListByCategory; }
	 */
	
	
	
	
	
	public List<Products> searchByCategory(String name) {
		  List<Products> productList = repository.findAll();
		  List<Products> productListbyCategory = new ArrayList<Products>();
		  for(Products p : productList) {
			  if(p.getCategory().equalsIgnoreCase(name)) {
				  productListbyCategory.add(p);
			  }
		  }
		  return productListbyCategory;
		   }
	

	public String deleteLowRatingProduct() {
		int count= 0;
		List<Products> products = repository.findAll();
		List<Products> itemToBeDeleted = products.stream().filter(product -> product.getRating()<2).collect(Collectors.toList());
			
		for (Products p : itemToBeDeleted) {
			repository.delete(p);
			count++;
		}
		if(count>0) {
			return count+" product has rating less than 2 and removed";
		}
		else {
			return "No product has rating less than 2";
		}
	}

}
