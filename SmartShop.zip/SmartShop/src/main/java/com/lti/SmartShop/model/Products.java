package com.lti.SmartShop.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="products")
public class Products {
	
	
private long id;
private String name;
private String category;
private double quantity;
private double unitPrice;
private int rating;
private double totalPrice;


@Column(name = "total_price", nullable = false)
public double getTotalPrice() {
	return totalPrice;
}
public void setTotalPrice(double totalPrice) {
	this.totalPrice = totalPrice;
}
@Id
@GeneratedValue(strategy = GenerationType.SEQUENCE)
public long getId() {
	return id;
}
public void setId(long id) {
	this.id = id;
}

@Column(name = "name", nullable = false)
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}

@Column(name = "category", nullable= true)
public String getCategory() {
	return category;
}

public void setCategory(String category) {
	this.category = category;
}

@Column(name = "quantity", nullable = false)
public double getQuantity() {
	return quantity;
}
public void setQuantity(double quantity) {
	this.quantity = quantity;
}

@Column(name = "unit_price", nullable = false)
public double getUnitPrice() {
	return unitPrice;
}
public void setUnitPrice(double unitPrice) {
	this.unitPrice = unitPrice;
}

@Column(name = "rating", nullable = false)
public int getRating() {
	return rating;
}
public void setRating(int rating) {
	this.rating = rating;
}
}
