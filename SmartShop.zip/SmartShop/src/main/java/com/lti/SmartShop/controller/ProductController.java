package com.lti.SmartShop.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lti.SmartShop.exception.ResourceNotFoundException;
import com.lti.SmartShop.model.Products;
import com.lti.SmartShop.service.ProductService;

@RestController
@RequestMapping("/api.")
public class ProductController {

	@Autowired
	ProductService service;

	@PostMapping("/addProdcut")
	public Products addProduct(@RequestBody Products product) {
		return service.addProduct(product);
	}

	@GetMapping("/getAllProducts")
	public List<Products> getAllProducts() {
		return service.getAllProducts();
	}
	
	@GetMapping("/getProductByName/{name}")
	public Products searchProductByName(@PathVariable String name)
	{
		return service.searchByName(name);
	}
	
	@GetMapping("/getProductByCategory/{category}")
	public List<Products> searchProductByCategory(@PathVariable String category)
	{
		return service.searchByCategory(category);
	}
	
	@PutMapping("/updateProductDetails/{id}")
	public Products updateProductDetails(@PathVariable(value = "id") Long id,
			 @RequestBody Products products) throws ResourceNotFoundException
	{
		return service.updateProduct(products, id);
	}
	
	@GetMapping("/updateTotalPrice")
	public String updateTotalPrice() {
		return service.updateTotalPrice();
	}
	
	@DeleteMapping("/deleteLowRatingProduct")
	public String deleteLowRatingProducts() {
		return service.deleteLowRatingProduct();
	}
}
